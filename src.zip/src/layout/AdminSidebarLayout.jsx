import { Outlet, useNavigate, NavLink } from "react-router-dom";
import { useState, useEffect } from "react";

function AdminSidebarLayout() {
    const navigate = useNavigate();
    const name = localStorage.getItem("studentName");
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        document.body.style.overflow = showModal ? "hidden" : "auto";

        // cleanup (VERY IMPORTANT)
        return () => {
            document.body.style.overflow = "auto";
        };
    }, [showModal]);

    return (
        <div className="flex">

            {/* SIDEBAR */}
            <div className="fixed top-0 left-0 h-screen w-64 bg-gradient-to-b from-gray-900 to-gray-800 text-white flex flex-col justify-between p-5 shadow-xl">

                <div>
                    <h2 className="text-xl font-bold mb-6">⚙️ Admin Panel</h2>

                    <p className="mb-6 text-sm text-gray-300">
                        👋 {name}
                    </p>

                    <nav className="flex flex-col gap-3">

                        <NavLink
                            to="/admin"
                            end
                            className={({ isActive }) =>
                                `p-2 rounded ${isActive ? "bg-blue-500" : "hover:bg-gray-700"}`
                            }
                        >
                            📊 Dashboard
                        </NavLink>

                        <NavLink
                            to="/admin/questions"
                            className={({ isActive }) =>
                                `p-2 rounded ${isActive ? "bg-blue-500" : "hover:bg-gray-700"}`
                            }
                        >
                            📝 Manage Questions
                        </NavLink>

                    </nav>
                </div>

                <button
                    onClick={() => setShowModal(true)}
                    className="bg-red-500 px-3 py-2 rounded hover:bg-red-600 w-full"
                >
                    Logout 🚪
                </button>
            </div>

            {/* MAIN */}
            <div className="flex-1 ml-64 bg-gray-100 min-h-screen p-8">
                <div className="max-w-5xl mx-auto">
                    <Outlet />
                </div>
            </div>

            {/* ✅ MODAL */}
            {showModal && (
                <div className="fixed inset-0 z-50 flex">

                    {/* sidebar space */}
                    <div className="w-64"></div>

                    {/* overlay */}
                    <div
                        onClick={() => setShowModal(false)}
                        className="flex-1 flex items-center justify-center bg-black/40 backdrop-blur-[2px]"
                    >
                        <div
                            onClick={(e) => e.stopPropagation()}
                            className="bg-white rounded-2xl shadow-2xl border border-gray-200 p-6 w-80 text-center animate-[fadeIn_0.2s_ease]"
                        >
                            <h2 className="text-lg font-semibold mb-4">
                                🚪 Confirm Logout
                            </h2>

                            <p className="text-gray-500 mb-6">
                                Are you sure you want to logout?
                            </p>

                            <div className="flex justify-center gap-4">

                                <button
                                    onClick={() => {
                                        localStorage.clear();
                                        navigate("/");
                                    }}
                                    className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                                >
                                    Yes
                                </button>

                                <button
                                    onClick={() => setShowModal(false)}
                                    className="bg-gray-200 px-4 py-2 rounded hover:bg-gray-300"
                                >
                                    Cancel
                                </button>

                            </div>
                        </div>
                    </div>
                </div>

            )
            }

        </div >
    );
}

export default AdminSidebarLayout;