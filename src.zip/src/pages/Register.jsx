import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import BASE_URL from "../api/api";

function Register() {
  const [studentName, setStudentName] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false); // 👁
  const [loading, setLoading] = useState(false); // ⏳
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const navigate = useNavigate();

  const handleRegister = async () => {
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch(`${BASE_URL}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentName, password }),
      });

      if (res.ok) {
        setSuccess("✅ Registered successfully!");
        setTimeout(() => navigate("/"), 1500);
      } else {
        setError("❌ Registration failed");
      }
    } catch (err) {
      setError("❌ Server error");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-gray-200">

      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm">

        <h2 className="text-2xl font-bold text-center mb-6">
          📝 Register
        </h2>

        {/* SUCCESS */}
        {success && (
          <p className="text-green-600 text-sm text-center mb-3">
            {success}
          </p>
        )}

        {/* ERROR */}
        {error && (
          <p className="text-red-500 text-sm text-center mb-3">
            {error}
          </p>
        )}

        {/* NAME */}
        <input
          type="text"
          placeholder="Enter Name"
          value={studentName}
          onChange={(e) => setStudentName(e.target.value)}
          className="w-full mb-4 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />

        {/* PASSWORD + 👁 */}
        <div className="relative mb-5">
          <input
            type={show ? "text" : "password"}
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />

          <span
            onClick={() => setShow(!show)}
            className="absolute right-3 top-3 cursor-pointer text-gray-500"
          >
            {show ? "🙈" : "👁"}
          </span>
        </div>

        {/* BUTTON */}
        <button
          onClick={handleRegister}
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-500 to-blue-700 text-white py-3 rounded-lg font-semibold flex justify-center items-center gap-2 hover:scale-105 transition disabled:opacity-70"
        >
          {loading ? (
            <>
              <span className="animate-spin border-2 border-white border-t-transparent rounded-full w-5 h-5"></span>
              Registering...
            </>
          ) : (
            "Register"
          )}
        </button>

        {/* LOGIN LINK */}
        <p className="text-center text-sm mt-4">
          Already have an account?{" "}
          <Link
            to="/"
            className="text-blue-600 font-semibold hover:underline"
          >
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Register;