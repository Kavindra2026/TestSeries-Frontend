import { useEffect, useState } from "react";
import BASE_URL from "../api/api";
import { getAuthHeader } from "../utils/auth";

function Analysis() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const answers = JSON.parse(localStorage.getItem("answers"));

    fetch(`${BASE_URL}/result/analysis`, {
      method: "POST",
      headers: {
        ...getAuthHeader(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ answers }),
    })
      .then((res) => res.json())
      .then(setData);
  }, []);

  // 🔥 RESULT SUMMARY
  const result = JSON.parse(localStorage.getItem("result")) || {};

  const correctCount = result.correctAnswers || 0;
  const wrongCount = result.wrongAnswers || 0;
  const totalQuestions = correctCount + wrongCount;

  const accuracy =
    totalQuestions > 0
      ? Math.round((correctCount / totalQuestions) * 100)
      : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-100 py-6 px-4">

      <div className="max-w-3xl mx-auto bg-white p-5 rounded-xl shadow-lg">

        <h2 className="text-xl font-bold text-center mb-5">
          📊 Detailed Analysis
        </h2>

        {/* 🔥 SUMMARY */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5 text-center text-sm">

          <div className="bg-green-100 py-2 rounded-md">
            ✅ {correctCount}
          </div>

          <div className="bg-red-100 py-2 rounded-md">
            ❌ {wrongCount}
          </div>

          <div className="bg-blue-100 py-2 rounded-md">
            📊 {accuracy}%
          </div>

          <div className="bg-gray-100 py-2 rounded-md">
            📋 {totalQuestions}
          </div>

        </div>

        {/* EMPTY */}
        {data.length === 0 ? (
          <p className="text-center text-green-600 font-medium">
            🎉 All answers are correct!
          </p>
        ) : (
          <div className="space-y-4">

            {data.map((item, i) => (
              <div
                key={i}
                className={`bg-gray-50 p-3 rounded-lg border-l-4 hover:shadow-md transition
                  ${
                    item.userAnswer === "Not Answered"
                      ? "border-yellow-400"
                      : item.userAnswer === item.correctAnswer
                      ? "border-green-500"
                      : "border-red-500"
                  }
                `}
              >

                {/* QUESTION */}
                <p className="font-semibold text-base mb-2">
                  ❓ {item.question}
                </p>

                {/* OPTIONS */}
                <div className="space-y-1 text-sm mb-2">

                  {["A", "B", "C", "D"].map((opt) => {
                    const value = item[`option${opt}`];

                    return (
                      <div
                        key={opt}
                        className={`px-3 py-1 rounded-md flex gap-2 items-center transition
                          ${
                            opt === item.correctAnswer
                              ? "bg-green-100 text-green-700 font-medium"
                              : opt === item.userAnswer
                              ? "bg-red-100 text-red-600"
                              : "bg-white hover:bg-gray-100"
                          }
                        `}
                      >
                        <span className="font-semibold">{opt}:</span>
                        <span>{value}</span>
                      </div>
                    );
                  })}

                </div>

                {/* ANSWERS */}
                <div className="text-xs space-y-1">

                  <p className="text-green-600 font-medium">
                    ✅ Correct: {item.correctAnswer}
                  </p>

                  <p className="text-red-500 font-medium">
                    {item.userAnswer === "Not Answered"
                      ? "⏭ Not Attempted"
                      : `❌ Your Answer: ${item.userAnswer}`}
                  </p>

                </div>

              </div>
            ))}

          </div>
        )}
      </div>
    </div>
  );
}

export default Analysis;